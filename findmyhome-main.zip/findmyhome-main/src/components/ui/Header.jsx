import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const navigationItems = [
    { name: 'Dashboard', path: '/user-dashboard', icon: 'Home' },
    { name: 'Properties', path: '/properties', icon: 'Building' },
    { name: 'Search', path: '/search', icon: 'Search' },
    { name: 'Favorites', path: '/favorites', icon: 'Heart' },
  ];

  const secondaryItems = [
    { name: 'Settings', path: '/settings', icon: 'Settings' },
    { name: 'Help', path: '/help', icon: 'HelpCircle' },
    { name: 'Profile', path: '/profile', icon: 'User' },
  ];

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-surface border-b border-border shadow-soft">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Logo */}
        <Link to="/user-dashboard" className="flex items-center space-x-2 transition-smooth hover:opacity-80">
          <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
            <Icon name="Home" size={20} color="white" />
          </div>
          <span className="text-xl font-semibold text-text-primary">FindMyHome</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-1">
          {navigationItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-smooth ${
                isActivePath(item?.path)
                  ? 'bg-primary text-primary-foreground'
                  : 'text-text-secondary hover:text-text-primary hover:bg-muted'
              }`}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.name}</span>
            </Link>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden lg:flex items-center space-x-3">
          {/* More Menu */}
          <div className="relative group">
            <Button
              variant="ghost"
              size="sm"
              iconName="MoreHorizontal"
              iconSize={16}
              className="text-text-secondary hover:text-text-primary"
            >
              More
            </Button>
            <div className="absolute right-0 top-full mt-1 w-48 bg-popover border border-border rounded-md shadow-soft-hover opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-smooth">
              <div className="py-1">
                {secondaryItems?.map((item) => (
                  <Link
                    key={item?.path}
                    to={item?.path}
                    className="flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-muted transition-smooth"
                  >
                    <Icon name={item?.icon} size={16} />
                    <span>{item?.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* User Menu */}
          <div className="relative group">
            <Button
              variant="ghost"
              size="sm"
              iconName="User"
              iconSize={16}
              className="text-text-secondary hover:text-text-primary"
            >
              Account
            </Button>
            <div className="absolute right-0 top-full mt-1 w-48 bg-popover border border-border rounded-md shadow-soft-hover opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-smooth">
              <div className="py-1">
                <Link
                  to="/profile"
                  className="flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-muted transition-smooth"
                >
                  <Icon name="User" size={16} />
                  <span>Profile</span>
                </Link>
                <Link
                  to="/settings"
                  className="flex items-center space-x-2 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-muted transition-smooth"
                >
                  <Icon name="Settings" size={16} />
                  <span>Settings</span>
                </Link>
                <hr className="my-1 border-border" />
                <button
                  onClick={() => {/* Handle logout */}}
                  className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-muted transition-smooth text-left"
                >
                  <Icon name="LogOut" size={16} />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          iconName={isMobileMenuOpen ? "X" : "Menu"}
          iconSize={20}
          onClick={toggleMobileMenu}
          className="lg:hidden text-text-secondary hover:text-text-primary"
        />
      </div>
      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-surface border-t border-border">
          <nav className="px-4 py-2 space-y-1">
            {navigationItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`flex items-center space-x-3 px-3 py-3 rounded-md text-sm font-medium transition-smooth ${
                  isActivePath(item?.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-secondary hover:text-text-primary hover:bg-muted'
                }`}
              >
                <Icon name={item?.icon} size={18} />
                <span>{item?.name}</span>
              </Link>
            ))}
            
            <hr className="my-2 border-border" />
            
            {secondaryItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center space-x-3 px-3 py-3 rounded-md text-sm font-medium text-text-secondary hover:text-text-primary hover:bg-muted transition-smooth"
              >
                <Icon name={item?.icon} size={18} />
                <span>{item?.name}</span>
              </Link>
            ))}
            
            <hr className="my-2 border-border" />
            
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                /* Handle logout */
              }}
              className="flex items-center space-x-3 w-full px-3 py-3 rounded-md text-sm font-medium text-text-secondary hover:text-text-primary hover:bg-muted transition-smooth text-left"
            >
              <Icon name="LogOut" size={18} />
              <span>Sign Out</span>
            </button>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;