import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PropertyCard = ({ property, onSave, onShare, onSchedule }) => {
  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })?.format(price);
  };

  return (
    <div className="bg-card rounded-lg border border-border shadow-soft hover:shadow-soft-hover transition-smooth overflow-hidden">
      <div className="relative h-48 overflow-hidden">
        <Image
          src={property?.image}
          alt={property?.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3">
          <Button
            variant="ghost"
            size="icon"
            iconName={property?.isSaved ? "Heart" : "Heart"}
            iconSize={20}
            onClick={() => onSave(property?.id)}
            className={`bg-white/90 hover:bg-white ${
              property?.isSaved ? 'text-destructive' : 'text-text-secondary'
            }`}
          />
        </div>
        {property?.isNew && (
          <div className="absolute top-3 left-3 bg-accent text-accent-foreground px-2 py-1 rounded-md text-xs font-medium">
            New
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-lg font-semibold text-text-primary line-clamp-1">
            {property?.title}
          </h3>
          <span className="text-lg font-bold text-primary ml-2">
            {formatPrice(property?.price)}
          </span>
        </div>
        
        <p className="text-text-secondary text-sm mb-3 line-clamp-1">
          {property?.address}
        </p>
        
        <div className="flex items-center space-x-4 mb-4 text-sm text-text-secondary">
          <div className="flex items-center space-x-1">
            <Icon name="Bed" size={16} />
            <span>{property?.bedrooms} beds</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Bath" size={16} />
            <span>{property?.bathrooms} baths</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Square" size={16} />
            <span>{property?.sqft?.toLocaleString()} sqft</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="Share"
            iconPosition="left"
            iconSize={16}
            onClick={() => onShare(property?.id)}
            className="flex-1"
          >
            Share
          </Button>
          <Button
            variant="default"
            size="sm"
            iconName="Calendar"
            iconPosition="left"
            iconSize={16}
            onClick={() => onSchedule(property?.id)}
            className="flex-1"
          >
            Schedule Tour
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;