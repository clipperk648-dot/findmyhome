import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActionCard = ({ title, description, iconName, buttonText, onClick, hasNotification = false }) => {
  return (
    <div className="bg-card rounded-lg border border-border p-6 shadow-soft hover:shadow-soft-hover transition-smooth">
      <div className="flex items-start space-x-4">
        <div className="relative">
          <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg">
            <Icon name={iconName} size={24} color="var(--color-primary)" />
          </div>
          {hasNotification && (
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full"></div>
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-text-primary mb-1">
            {title}
          </h3>
          <p className="text-text-secondary text-sm mb-4">
            {description}
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={onClick}
            className="w-full sm:w-auto"
          >
            {buttonText}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickActionCard;