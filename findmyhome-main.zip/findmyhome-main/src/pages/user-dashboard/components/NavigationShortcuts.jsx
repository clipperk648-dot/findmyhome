import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const NavigationShortcuts = ({ shortcuts }) => {
  return (
    <div className="bg-card rounded-lg border border-border p-6 shadow-soft">
      <h3 className="text-lg font-semibold text-text-primary mb-4">
        Quick Access
      </h3>
      <div className="space-y-2">
        {shortcuts?.map((shortcut, index) => (
          <Link
            key={index}
            to={shortcut?.path}
            className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-smooth group"
          >
            <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-smooth">
              <Icon name={shortcut?.icon} size={16} color="var(--color-primary)" />
            </div>
            <div className="flex-1">
              <span className="text-sm font-medium text-text-primary">
                {shortcut?.title}
              </span>
              {shortcut?.count && (
                <span className="text-xs text-text-secondary ml-2">
                  ({shortcut?.count})
                </span>
              )}
            </div>
            <Icon name="ChevronRight" size={16} color="var(--color-text-secondary)" />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default NavigationShortcuts;