import React from 'react';
import PropertyCard from './PropertyCard';

const PropertyFeed = ({ properties, onSave, onShare, onSchedule }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-text-primary">
          Recommended for You
        </h2>
        <button className="text-primary hover:text-primary/80 text-sm font-medium transition-smooth">
          View All
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {properties?.map((property) => (
          <PropertyCard
            key={property?.id}
            property={property}
            onSave={onSave}
            onShare={onShare}
            onSchedule={onSchedule}
          />
        ))}
      </div>
    </div>
  );
};

export default PropertyFeed;