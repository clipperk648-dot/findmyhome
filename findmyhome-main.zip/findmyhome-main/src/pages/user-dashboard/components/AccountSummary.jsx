import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AccountSummary = ({ user, profileCompletion, recentActivity }) => {
  const getCompletionColor = (percentage) => {
    if (percentage >= 80) return 'text-success';
    if (percentage >= 50) return 'text-warning';
    return 'text-destructive';
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 shadow-soft">
      <div className="flex items-center space-x-4 mb-6">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
          <Icon name="User" size={32} color="var(--color-primary)" />
        </div>
        <div className="flex-1">
          <h2 className="text-xl font-semibold text-text-primary">
            Welcome back, {user?.firstName}!
          </h2>
          <p className="text-text-secondary">
            {user?.email}
          </p>
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
          <div className="flex items-center space-x-3">
            <Icon name="User" size={20} color="var(--color-text-secondary)" />
            <span className="text-sm font-medium text-text-primary">
              Profile Completion
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <span className={`text-sm font-semibold ${getCompletionColor(profileCompletion)}`}>
              {profileCompletion}%
            </span>
            <div className="w-16 h-2 bg-border rounded-full overflow-hidden">
              <div
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${profileCompletion}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-text-primary">Recent Activity</h3>
          {recentActivity?.map((activity, index) => (
            <div key={index} className="flex items-center space-x-3 text-sm">
              <Icon name={activity?.icon} size={16} color="var(--color-text-secondary)" />
              <span className="text-text-secondary flex-1">{activity?.description}</span>
              <span className="text-text-secondary text-xs">{activity?.time}</span>
            </div>
          ))}
        </div>
        
        <Button
          variant="outline"
          size="sm"
          iconName="Settings"
          iconPosition="left"
          iconSize={16}
          className="w-full"
        >
          Manage Account
        </Button>
      </div>
    </div>
  );
};

export default AccountSummary;