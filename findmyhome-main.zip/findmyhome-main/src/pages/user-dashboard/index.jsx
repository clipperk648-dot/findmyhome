import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import PropertyFeed from './components/PropertyFeed';
import QuickActionCard from './components/QuickActionCard';
import AccountSummary from './components/AccountSummary';
import NavigationShortcuts from './components/NavigationShortcuts';

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  // Mock user data
  const mockUser = {
    id: 1,
    firstName: "Sarah",
    lastName: "Johnson",
    email: "sarah.johnson@email.com",
    profileImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face"
  };

  // Mock properties data
  const mockProperties = [
    {
      id: 1,
      title: "Modern Downtown Condo",
      address: "123 Main Street, Downtown, NY 10001",
      price: 850000,
      bedrooms: 2,
      bathrooms: 2,
      sqft: 1200,
      image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400&h=300&fit=crop",
      isSaved: true,
      isNew: true
    },
    {
      id: 2,
      title: "Spacious Family Home",
      address: "456 Oak Avenue, Suburbia, NY 10002",
      price: 675000,
      bedrooms: 4,
      bathrooms: 3,
      sqft: 2400,
      image: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=400&h=300&fit=crop",
      isSaved: false,
      isNew: false
    },
    {
      id: 3,
      title: "Luxury Waterfront Villa",
      address: "789 Lake Drive, Lakeside, NY 10003",
      price: 1250000,
      bedrooms: 5,
      bathrooms: 4,
      sqft: 3200,
      image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400&h=300&fit=crop",
      isSaved: true,
      isNew: false
    },
    {
      id: 4,
      title: "Cozy Studio Apartment",
      address: "321 Pine Street, Midtown, NY 10004",
      price: 425000,
      bedrooms: 1,
      bathrooms: 1,
      sqft: 650,
      image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&h=300&fit=crop",
      isSaved: false,
      isNew: true
    },
    {
      id: 5,
      title: "Victorian Townhouse",
      address: "654 Elm Street, Historic District, NY 10005",
      price: 950000,
      bedrooms: 3,
      bathrooms: 2,
      sqft: 1800,
      image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400&h=300&fit=crop",
      isSaved: false,
      isNew: false
    },
    {
      id: 6,
      title: "Modern Penthouse Suite",
      address: "987 Sky Tower, Upper East, NY 10006",
      price: 2100000,
      bedrooms: 3,
      bathrooms: 3,
      sqft: 2800,
      image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=400&h=300&fit=crop",
      isSaved: true,
      isNew: true
    }
  ];

  // Mock quick actions data
  const quickActions = [
    {
      title: "Start New Search",
      description: "Find properties that match your criteria",
      iconName: "Search",
      buttonText: "Search Properties",
      hasNotification: false
    },
    {
      title: "Saved Search Alerts",
      description: "3 new properties match your saved searches",
      iconName: "Bell",
      buttonText: "View Alerts",
      hasNotification: true
    },
    {
      title: "Schedule Tours",
      description: "Book viewings for your favorite properties",
      iconName: "Calendar",
      buttonText: "Schedule Now",
      hasNotification: false
    },
    {
      title: "Market Insights",
      description: "Get the latest market trends and analysis",
      iconName: "TrendingUp",
      buttonText: "View Insights",
      hasNotification: false
    }
  ];

  // Mock recent activity data
  const recentActivity = [
    {
      icon: "Eye",
      description: "Viewed Modern Downtown Condo",
      time: "2 hours ago"
    },
    {
      icon: "Heart",
      description: "Saved Luxury Waterfront Villa",
      time: "1 day ago"
    },
    {
      icon: "Search",
      description: "Created new search alert",
      time: "2 days ago"
    },
    {
      icon: "Calendar",
      description: "Scheduled tour for Family Home",
      time: "3 days ago"
    }
  ];

  // Mock navigation shortcuts
  const navigationShortcuts = [
    {
      title: "Saved Properties",
      icon: "Heart",
      path: "/saved-properties",
      count: 12
    },
    {
      title: "Search History",
      icon: "History",
      path: "/search-history",
      count: 8
    },
    {
      title: "Scheduled Tours",
      icon: "Calendar",
      path: "/scheduled-tours",
      count: 3
    },
    {
      title: "Account Settings",
      icon: "Settings",
      path: "/settings"
    },
    {
      title: "Help & Support",
      icon: "HelpCircle",
      path: "/help"
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setUser(mockUser);
      setProperties(mockProperties);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleSaveProperty = (propertyId) => {
    setProperties(prev => prev?.map(property => 
      property?.id === propertyId 
        ? { ...property, isSaved: !property?.isSaved }
        : property
    ));
  };

  const handleShareProperty = (propertyId) => {
    const property = properties?.find(p => p?.id === propertyId);
    if (property) {
      // Mock share functionality
      alert(`Sharing: ${property?.title}`);
    }
  };

  const handleScheduleTour = (propertyId) => {
    const property = properties?.find(p => p?.id === propertyId);
    if (property) {
      // Mock schedule functionality
      alert(`Scheduling tour for: ${property?.title}`);
    }
  };

  const handleQuickAction = (actionTitle) => {
    // Mock quick action functionality
    alert(`Executing: ${actionTitle}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-text-secondary">Loading your dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-text-primary mb-2">
              Welcome back, {user?.firstName}!
            </h1>
            <p className="text-text-secondary">
              Discover your perfect home with personalized recommendations
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content Area */}
            <div className="lg:col-span-3 space-y-8">
              {/* Quick Actions */}
              <section>
                <h2 className="text-xl font-semibold text-text-primary mb-4">
                  Quick Actions
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {quickActions?.map((action, index) => (
                    <QuickActionCard
                      key={index}
                      title={action?.title}
                      description={action?.description}
                      iconName={action?.iconName}
                      buttonText={action?.buttonText}
                      hasNotification={action?.hasNotification}
                      onClick={() => handleQuickAction(action?.title)}
                    />
                  ))}
                </div>
              </section>

              {/* Property Feed */}
              <section>
                <PropertyFeed
                  properties={properties}
                  onSave={handleSaveProperty}
                  onShare={handleShareProperty}
                  onSchedule={handleScheduleTour}
                />
              </section>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
              {/* Account Summary */}
              <AccountSummary
                user={user}
                profileCompletion={75}
                recentActivity={recentActivity}
              />

              {/* Navigation Shortcuts */}
              <NavigationShortcuts shortcuts={navigationShortcuts} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default UserDashboard;