import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Image from '../../components/AppImage';
import RegistrationForm from './components/RegistrationForm';
import SocialRegistration from './components/SocialRegistration';
import SuccessMessage from './components/SuccessMessage';

const UserRegistration = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  // Mock registration data for demonstration
  const mockUsers = [
    { email: 'john.doe@example.com', password: 'Password123!' },
    { email: 'jane.smith@example.com', password: 'SecurePass456!' },
    { email: 'mike.johnson@example.com', password: 'MyPassword789!' }
  ];

  const handleRegistration = async (formData) => {
    setIsLoading(true);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Check if email already exists (mock validation)
      const existingUser = mockUsers?.find(user => user?.email?.toLowerCase() === formData?.email?.toLowerCase());
      
      if (existingUser) {
        throw new Error('An account with this email already exists');
      }

      // Mock successful registration
      console.log('Registration data:', formData);
      setUserEmail(formData?.email);
      setRegistrationSuccess(true);
      
    } catch (error) {
      console.error('Registration error:', error);
      // In a real app, you would show error messages to the user
      alert(error?.message || 'Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialRegistration = async (provider) => {
    setIsLoading(true);
    
    try {
      // Simulate social registration delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock successful social registration
      const mockEmail = provider === 'google' ? 'user@gmail.com' : 'user@facebook.com';
      setUserEmail(mockEmail);
      setRegistrationSuccess(true);
      
    } catch (error) {
      console.error('Social registration error:', error);
      alert('Social registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendEmail = async () => {
    setIsResending(true);
    
    try {
      // Simulate resend email delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock successful resend
      console.log('Verification email resent to:', userEmail);
      alert('Verification email has been resent successfully!');
      
    } catch (error) {
      console.error('Resend email error:', error);
      alert('Failed to resend email. Please try again.');
    } finally {
      setIsResending(false);
    }
  };

  const handleBackToLogin = () => {
    navigate('/user-login');
  };

  if (registrationSuccess) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet>
          <title>Registration Successful - FindMyHome</title>
          <meta name="description" content="Your FindMyHome account has been created successfully. Please verify your email to get started." />
        </Helmet>

        <div className="flex min-h-screen">
          {/* Left Side - Success Message */}
          <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
            <div className="w-full max-w-md">
              <SuccessMessage
                email={userEmail}
                onResendEmail={handleResendEmail}
                onBackToLogin={handleBackToLogin}
                isResending={isResending}
              />
            </div>
          </div>

          {/* Right Side - Image (Hidden on mobile) */}
          <div className="hidden lg:block lg:w-1/2 relative">
            <Image
              src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
              alt="Modern home exterior with beautiful landscaping"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/40"></div>
            <div className="absolute bottom-8 left-8 right-8 text-white">
              <h3 className="text-2xl font-semibold mb-2">Welcome to FindMyHome</h3>
              <p className="text-lg opacity-90">
                Your journey to finding the perfect home starts here
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Create Account - FindMyHome</title>
        <meta name="description" content="Join FindMyHome to discover your perfect property. Create your account and start exploring homes, apartments, and investment opportunities." />
      </Helmet>

      <div className="flex min-h-screen">
        {/* Left Side - Registration Form */}
        <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
          <div className="w-full max-w-md space-y-8">
            {/* Header */}
            <div className="text-center space-y-2">
              <Link to="/user-dashboard" className="inline-flex items-center space-x-2 text-primary hover:opacity-80 transition-smooth">
                <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
                  <Icon name="Home" size={24} color="white" />
                </div>
                <span className="text-2xl font-bold">FindMyHome</span>
              </Link>
              <div className="space-y-1">
                <h1 className="text-3xl font-bold text-text-primary">Create Account</h1>
                <p className="text-text-secondary">
                  Join thousands of users finding their perfect home
                </p>
              </div>
            </div>

            {/* Social Registration */}
            <SocialRegistration
              onSocialRegister={handleSocialRegistration}
              isLoading={isLoading}
            />

            {/* Registration Form */}
            <RegistrationForm
              onSubmit={handleRegistration}
              isLoading={isLoading}
            />

            {/* Login Link */}
            <div className="text-center">
              <p className="text-sm text-text-secondary">
                Already have an account?{' '}
                <Link
                  to="/user-login"
                  className="font-medium text-primary hover:underline transition-smooth"
                >
                  Sign in here
                </Link>
              </p>
            </div>

            {/* Security Notice */}
            <div className="bg-muted rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <Icon name="Shield" size={20} className="text-success flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-text-primary mb-1">Your data is secure</p>
                  <p className="text-text-secondary">
                    We use industry-standard encryption to protect your personal information and never share your data with third parties.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Hero Image */}
        <div className="hidden lg:block lg:w-1/2 relative">
          <Image
            src="https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=1000"
            alt="Beautiful modern house with large windows and landscaped garden"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-secondary/40"></div>
          
          {/* Overlay Content */}
          <div className="absolute inset-0 flex flex-col justify-end p-8 text-white">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold">Find Your Dream Home</h2>
              <p className="text-lg opacity-90 max-w-md">
                Discover thousands of properties, get personalized recommendations, and connect with trusted real estate professionals.
              </p>
              
              {/* Features */}
              <div className="space-y-3 mt-6">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <Icon name="Search" size={16} />
                  </div>
                  <span>Advanced property search filters</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <Icon name="Heart" size={16} />
                  </div>
                  <span>Save and organize your favorites</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                    <Icon name="Bell" size={16} />
                  </div>
                  <span>Get alerts for new listings</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserRegistration;