import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const RegistrationForm = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    userType: 'buyer',
    location: '',
    agreeToTerms: false,
    subscribeNewsletter: false
  });

  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const userTypes = [
    { value: 'buyer', label: 'Home Buyer' },
    { value: 'renter', label: 'Renter' },
    { value: 'investor', label: 'Investor' },
    { value: 'agent', label: 'Real Estate Agent' }
  ];

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex?.test(email);
  };

  const validatePassword = (password) => {
    const minLength = password?.length >= 8;
    const hasUpperCase = /[A-Z]/?.test(password);
    const hasLowerCase = /[a-z]/?.test(password);
    const hasNumbers = /\d/?.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/?.test(password);
    
    return {
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar,
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar
    };
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e?.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error when user starts typing
    if (errors?.[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    const newErrors = {};

    // Validation
    if (!formData?.firstName?.trim()) {
      newErrors.firstName = 'First name is required';
    }

    if (!formData?.lastName?.trim()) {
      newErrors.lastName = 'Last name is required';
    }

    if (!formData?.email?.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formData?.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData?.password) {
      newErrors.password = 'Password is required';
    } else if (!validatePassword(formData?.password)?.isValid) {
      newErrors.password = 'Password must meet all requirements';
    }

    if (!formData?.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData?.password !== formData?.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData?.location?.trim()) {
      newErrors.location = 'Preferred location is required';
    }

    if (!formData?.agreeToTerms) {
      newErrors.agreeToTerms = 'You must agree to the terms and conditions';
    }

    if (Object.keys(newErrors)?.length > 0) {
      setErrors(newErrors);
      return;
    }

    onSubmit(formData);
  };

  const passwordValidation = validatePassword(formData?.password);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Name Fields */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="First Name"
          type="text"
          name="firstName"
          value={formData?.firstName}
          onChange={handleInputChange}
          placeholder="Enter your first name"
          error={errors?.firstName}
          required
          disabled={isLoading}
        />
        <Input
          label="Last Name"
          type="text"
          name="lastName"
          value={formData?.lastName}
          onChange={handleInputChange}
          placeholder="Enter your last name"
          error={errors?.lastName}
          required
          disabled={isLoading}
        />
      </div>
      {/* Email */}
      <Input
        label="Email Address"
        type="email"
        name="email"
        value={formData?.email}
        onChange={handleInputChange}
        placeholder="Enter your email address"
        error={errors?.email}
        required
        disabled={isLoading}
      />
      {/* User Type */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-text-primary">
          I am a <span className="text-destructive">*</span>
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {userTypes?.map((type) => (
            <label
              key={type?.value}
              className={`flex items-center justify-center p-3 border rounded-md cursor-pointer transition-smooth ${
                formData?.userType === type?.value
                  ? 'border-primary bg-primary/5 text-primary' :'border-border hover:border-primary/50'
              }`}
            >
              <input
                type="radio"
                name="userType"
                value={type?.value}
                checked={formData?.userType === type?.value}
                onChange={handleInputChange}
                className="sr-only"
                disabled={isLoading}
              />
              <span className="text-sm font-medium">{type?.label}</span>
            </label>
          ))}
        </div>
      </div>
      {/* Location */}
      <Input
        label="Preferred Location"
        type="text"
        name="location"
        value={formData?.location}
        onChange={handleInputChange}
        placeholder="City, State or ZIP code"
        error={errors?.location}
        required
        disabled={isLoading}
      />
      {/* Password */}
      <div className="relative">
        <Input
          label="Password"
          type={showPassword ? "text" : "password"}
          name="password"
          value={formData?.password}
          onChange={handleInputChange}
          placeholder="Create a strong password"
          error={errors?.password}
          required
          disabled={isLoading}
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-9 text-text-secondary hover:text-text-primary transition-smooth"
          disabled={isLoading}
        >
          <Icon name={showPassword ? "EyeOff" : "Eye"} size={18} />
        </button>
      </div>
      {/* Password Strength Indicator */}
      {formData?.password && (
        <div className="space-y-2">
          <div className="text-sm font-medium text-text-primary">Password Requirements:</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className={`flex items-center space-x-2 ${passwordValidation?.minLength ? 'text-success' : 'text-text-secondary'}`}>
              <Icon name={passwordValidation?.minLength ? "Check" : "X"} size={14} />
              <span>At least 8 characters</span>
            </div>
            <div className={`flex items-center space-x-2 ${passwordValidation?.hasUpperCase ? 'text-success' : 'text-text-secondary'}`}>
              <Icon name={passwordValidation?.hasUpperCase ? "Check" : "X"} size={14} />
              <span>Uppercase letter</span>
            </div>
            <div className={`flex items-center space-x-2 ${passwordValidation?.hasLowerCase ? 'text-success' : 'text-text-secondary'}`}>
              <Icon name={passwordValidation?.hasLowerCase ? "Check" : "X"} size={14} />
              <span>Lowercase letter</span>
            </div>
            <div className={`flex items-center space-x-2 ${passwordValidation?.hasNumbers ? 'text-success' : 'text-text-secondary'}`}>
              <Icon name={passwordValidation?.hasNumbers ? "Check" : "X"} size={14} />
              <span>Number</span>
            </div>
            <div className={`flex items-center space-x-2 ${passwordValidation?.hasSpecialChar ? 'text-success' : 'text-text-secondary'}`}>
              <Icon name={passwordValidation?.hasSpecialChar ? "Check" : "X"} size={14} />
              <span>Special character</span>
            </div>
          </div>
        </div>
      )}
      {/* Confirm Password */}
      <div className="relative">
        <Input
          label="Confirm Password"
          type={showConfirmPassword ? "text" : "password"}
          name="confirmPassword"
          value={formData?.confirmPassword}
          onChange={handleInputChange}
          placeholder="Confirm your password"
          error={errors?.confirmPassword}
          required
          disabled={isLoading}
        />
        <button
          type="button"
          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
          className="absolute right-3 top-9 text-text-secondary hover:text-text-primary transition-smooth"
          disabled={isLoading}
        >
          <Icon name={showConfirmPassword ? "EyeOff" : "Eye"} size={18} />
        </button>
      </div>
      {/* Terms and Newsletter */}
      <div className="space-y-4">
        <Checkbox
          label={
            <span className="text-sm">
              I agree to the{' '}
              <a href="/terms" className="text-primary hover:underline">
                Terms of Service
              </a>{' '}
              and{' '}
              <a href="/privacy" className="text-primary hover:underline">
                Privacy Policy
              </a>
            </span>
          }
          checked={formData?.agreeToTerms}
          onChange={(e) => handleInputChange(e)}
          name="agreeToTerms"
          error={errors?.agreeToTerms}
          required
          disabled={isLoading}
        />

        <Checkbox
          label="Subscribe to our newsletter for property updates and market insights"
          checked={formData?.subscribeNewsletter}
          onChange={(e) => handleInputChange(e)}
          name="subscribeNewsletter"
          disabled={isLoading}
        />
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        variant="default"
        size="lg"
        fullWidth
        loading={isLoading}
        disabled={isLoading}
      >
        Create Account
      </Button>
    </form>
  );
};

export default RegistrationForm;