import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const SuccessMessage = ({ email, onResendEmail, onBackToLogin, isResending }) => {
  return (
    <div className="text-center space-y-6">
      {/* Success Icon */}
      <div className="flex justify-center">
        <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center">
          <Icon name="CheckCircle" size={32} color="var(--color-success)" />
        </div>
      </div>

      {/* Success Message */}
      <div className="space-y-2">
        <h2 className="text-2xl font-semibold text-text-primary">
          Account Created Successfully!
        </h2>
        <p className="text-text-secondary">
          We've sent a verification email to{' '}
          <span className="font-medium text-text-primary">{email}</span>
        </p>
      </div>

      {/* Instructions */}
      <div className="bg-muted rounded-lg p-4 text-left space-y-3">
        <h3 className="font-medium text-text-primary flex items-center space-x-2">
          <Icon name="Mail" size={18} />
          <span>Next Steps:</span>
        </h3>
        <ul className="space-y-2 text-sm text-text-secondary">
          <li className="flex items-start space-x-2">
            <Icon name="ArrowRight" size={16} className="mt-0.5 flex-shrink-0" />
            <span>Check your email inbox for our verification message</span>
          </li>
          <li className="flex items-start space-x-2">
            <Icon name="ArrowRight" size={16} className="mt-0.5 flex-shrink-0" />
            <span>Click the verification link to activate your account</span>
          </li>
          <li className="flex items-start space-x-2">
            <Icon name="ArrowRight" size={16} className="mt-0.5 flex-shrink-0" />
            <span>Start exploring properties and save your favorites</span>
          </li>
        </ul>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button
          variant="outline"
          fullWidth
          loading={isResending}
          onClick={onResendEmail}
          disabled={isResending}
        >
          <div className="flex items-center justify-center space-x-2">
            <Icon name="RefreshCw" size={18} />
            <span>Resend Verification Email</span>
          </div>
        </Button>

        <Button
          variant="ghost"
          fullWidth
          onClick={onBackToLogin}
        >
          Back to Login
        </Button>
      </div>

      {/* Help Text */}
      <div className="text-xs text-text-secondary">
        <p>
          Didn't receive the email? Check your spam folder or{' '}
          <button
            onClick={onResendEmail}
            className="text-primary hover:underline"
            disabled={isResending}
          >
            request a new one
          </button>
        </p>
      </div>
    </div>
  );
};

export default SuccessMessage;