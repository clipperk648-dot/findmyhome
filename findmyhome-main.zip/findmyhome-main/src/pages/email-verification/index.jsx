import React, { useState, useEffect } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import VerificationStatus from './components/VerificationStatus';
import ResendEmailSection from './components/ResendEmailSection';
import TroubleshootingTips from './components/TroubleshootingTips';
import NextStepsGuide from './components/NextStepsGuide';
import ContactSupport from './components/ContactSupport';

const EmailVerification = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [verificationStatus, setVerificationStatus] = useState('sent');
  const [userEmail, setUserEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Mock user data - in real app this would come from auth context or API
  const mockUserData = {
    email: "john.doe@example.com",
    firstName: "John",
    registrationDate: new Date()?.toISOString()
  };

  useEffect(() => {
    // Get email from URL params or use mock data
    const email = searchParams?.get('email') || mockUserData?.email;
    setUserEmail(email);

    // Check if this is a verification callback
    const token = searchParams?.get('token');
    const expired = searchParams?.get('expired');
    const error = searchParams?.get('error');

    if (token) {
      // Mock verification process
      setIsLoading(true);
      setTimeout(() => {
        if (expired === 'true') {
          setVerificationStatus('expired');
        } else if (error === 'true') {
          setVerificationStatus('error');
        } else {
          setVerificationStatus('verified');
          // Auto redirect to dashboard after successful verification
          setTimeout(() => {
            navigate('/user-dashboard');
          }, 3000);
        }
        setIsLoading(false);
      }, 2000);
    }
  }, [searchParams, navigate]);

  const handleResendEmail = () => {
    setIsLoading(true);
    // Mock API call
    setTimeout(() => {
      setVerificationStatus('sent');
      setIsLoading(false);
      // Show success message
      alert('Verification email sent successfully!');
    }, 1500);
  };

  const handleBackToLogin = () => {
    navigate('/user-login');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-text-secondary">Processing verification...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Email Verification - FindMyHome</title>
        <meta name="description" content="Verify your email address to complete your FindMyHome account setup and start finding your perfect home." />
      </Helmet>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="bg-surface border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link to="/user-login" className="flex items-center space-x-2">
                <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
                  <Icon name="Home" size={20} color="white" />
                </div>
                <span className="text-xl font-semibold text-text-primary">FindMyHome</span>
              </Link>
              
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBackToLogin}
                  iconName="ArrowLeft"
                  iconPosition="left"
                >
                  Back to Login
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Main Content */}
            <div className="space-y-6">
              {/* Welcome Message */}
              <div className="text-center lg:text-left">
                <h1 className="text-3xl font-bold text-text-primary mb-2">
                  {verificationStatus === 'verified' ? 'Welcome to FindMyHome!' : 'Verify Your Email'}
                </h1>
                <p className="text-text-secondary">
                  {verificationStatus === 'verified' 
                    ? 'Your account is now active and ready to use.' :'Complete your account setup to start finding your perfect home.'
                  }
                </p>
              </div>

              {/* Verification Status */}
              <VerificationStatus status={verificationStatus} email={userEmail} />

              {/* Resend Email Section */}
              {(verificationStatus === 'sent' || verificationStatus === 'expired' || verificationStatus === 'error') && (
                <ResendEmailSection onResend={handleResendEmail} email={userEmail} />
              )}

              {/* Next Steps Guide */}
              <NextStepsGuide isVerified={verificationStatus === 'verified'} />
            </div>

            {/* Right Column - Help & Support */}
            <div className="space-y-6">
              {/* Troubleshooting Tips */}
              {verificationStatus !== 'verified' && <TroubleshootingTips />}

              {/* Contact Support */}
              <ContactSupport />

              {/* Additional Info */}
              <div className="bg-card border border-border rounded-lg p-6">
                <h3 className="text-lg font-medium text-text-primary mb-3 flex items-center">
                  <Icon name="Shield" size={20} className="mr-2 text-success" />
                  Security & Privacy
                </h3>
                <div className="space-y-3 text-sm text-text-secondary">
                  <div className="flex items-start space-x-2">
                    <Icon name="Check" size={16} className="text-success mt-0.5" />
                    <p>Your email address is kept secure and never shared with third parties</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Check" size={16} className="text-success mt-0.5" />
                    <p>Verification links expire after 24 hours for your security</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Check" size={16} className="text-success mt-0.5" />
                    <p>All communications are encrypted and protected</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="mt-12 text-center">
            <div className="inline-flex items-center space-x-4 text-sm text-text-secondary">
              <Link to="/user-login" className="hover:text-primary transition-smooth">
                Sign In
              </Link>
              <span>•</span>
              <Link to="/user-registration" className="hover:text-primary transition-smooth">
                Create Account
              </Link>
              <span>•</span>
              <Link to="/password-reset" className="hover:text-primary transition-smooth">
                Reset Password
              </Link>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-surface border-t border-border mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <div className="flex items-center justify-center w-6 h-6 bg-primary rounded">
                  <Icon name="Home" size={16} color="white" />
                </div>
                <span className="text-lg font-semibold text-text-primary">FindMyHome</span>
              </div>
              <p className="text-sm text-text-secondary mb-4">
                Your trusted partner in finding the perfect home
              </p>
              <div className="flex items-center justify-center space-x-6 text-xs text-text-secondary">
                <a href="#" className="hover:text-primary transition-smooth">Privacy Policy</a>
                <a href="#" className="hover:text-primary transition-smooth">Terms of Service</a>
                <a href="#" className="hover:text-primary transition-smooth">Contact Us</a>
              </div>
              <p className="text-xs text-text-secondary mt-4">
                © {new Date()?.getFullYear()} FindMyHome. All rights reserved.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default EmailVerification;