import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const TroubleshootingTips = () => {
  const [expandedTip, setExpandedTip] = useState(null);

  const tips = [
    {
      id: 1,
      title: "Check Your Spam Folder",
      icon: "AlertTriangle",
      content: "Verification emails sometimes end up in spam or junk folders. Look for emails from FindMyHome or noreply@findmyhome.com and mark them as 'Not Spam' to ensure future emails reach your inbox."
    },
    {
      id: 2,
      title: "Email Delivery Time",
      icon: "Clock",
      content: "Verification emails typically arrive within 2-5 minutes. During peak hours, delivery may take up to 15 minutes. Please wait a few minutes before requesting a new email."
    },
    {
      id: 3,
      title: "Correct Email Address",
      icon: "Mail",
      content: "Ensure you entered the correct email address during registration. If you made a typo, you'll need to register again with the correct email address."
    },
    {
      id: 4,
      title: "Email Provider Issues",
      icon: "Server",
      content: "Some email providers have strict filtering. Try using a different email address (Gmail, Outlook, or Yahoo) if you continue experiencing issues."
    }
  ];

  const toggleTip = (tipId) => {
    setExpandedTip(expandedTip === tipId ? null : tipId);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-medium text-text-primary mb-4 flex items-center">
        <Icon name="HelpCircle" size={20} className="mr-2 text-primary" />
        Troubleshooting Tips
      </h3>
      <div className="space-y-3">
        {tips?.map((tip) => (
          <div key={tip?.id} className="border border-border rounded-md">
            <button
              onClick={() => toggleTip(tip?.id)}
              className="w-full flex items-center justify-between p-3 text-left hover:bg-muted transition-smooth"
            >
              <div className="flex items-center">
                <Icon name={tip?.icon} size={16} className="mr-3 text-primary" />
                <span className="text-sm font-medium text-text-primary">
                  {tip?.title}
                </span>
              </div>
              <Icon 
                name={expandedTip === tip?.id ? "ChevronUp" : "ChevronDown"} 
                size={16} 
                className="text-text-secondary" 
              />
            </button>
            
            {expandedTip === tip?.id && (
              <div className="px-3 pb-3">
                <p className="text-sm text-text-secondary leading-relaxed pl-7">
                  {tip?.content}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TroubleshootingTips;