import React, { useState, useEffect } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ResendEmailSection = ({ onResend, email }) => {
  const [cooldown, setCooldown] = useState(0);
  const [resendCount, setResendCount] = useState(0);

  useEffect(() => {
    if (cooldown > 0) {
      const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldown]);

  const handleResend = () => {
    onResend();
    setResendCount(prev => prev + 1);
    setCooldown(60); // 60 second cooldown
  };

  const canResend = cooldown === 0 && resendCount < 5;

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="text-center">
        <div className="flex justify-center mb-3">
          <Icon name="RefreshCw" size={24} className="text-text-secondary" />
        </div>
        <h3 className="text-lg font-medium text-text-primary mb-2">
          Didn't receive the email?
        </h3>
        <p className="text-sm text-text-secondary mb-4">
          Check your spam folder or request a new verification email
        </p>
        
        {canResend ? (
          <Button
            variant="outline"
            onClick={handleResend}
            iconName="Send"
            iconPosition="left"
            className="mb-3"
          >
            Resend Verification Email
          </Button>
        ) : (
          <Button
            variant="outline"
            disabled
            className="mb-3"
          >
            {cooldown > 0 
              ? `Resend in ${cooldown}s` 
              : resendCount >= 5 
                ? 'Maximum attempts reached' :'Resend Email'
            }
          </Button>
        )}

        {resendCount > 0 && (
          <p className="text-xs text-text-secondary">
            Emails sent: {resendCount}/5 to {email}
          </p>
        )}
      </div>
    </div>
  );
};

export default ResendEmailSection;