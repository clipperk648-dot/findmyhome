import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ContactSupport = () => {
  const supportOptions = [
    {
      id: 1,
      title: "Email Support",
      description: "Get help via email within 24 hours",
      icon: "Mail",
      contact: "support@findmyhome.com",
      action: "Send Email"
    },
    {
      id: 2,
      title: "Live Chat",
      description: "Chat with our support team (9 AM - 6 PM EST)",
      icon: "MessageCircle",
      contact: "Available Monday - Friday",
      action: "Start Chat"
    },
    {
      id: 3,
      title: "Help Center",
      description: "Browse our comprehensive FAQ and guides",
      icon: "BookOpen",
      contact: "Self-service resources",
      action: "Visit Help Center"
    }
  ];

  const handleContactSupport = (option) => {
    switch (option?.id) {
      case 1:
        window.location.href = `mailto:${option?.contact}?subject=Email Verification Issue&body=Hello, I'm having trouble with email verification for my FindMyHome account.`;
        break;
      case 2:
        // Mock live chat functionality
        alert('Live chat feature will be available soon. Please use email support for now.');
        break;
      case 3:
        // Mock help center
        alert('Help center will open in a new window.');
        break;
      default:
        break;
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-medium text-text-primary mb-4 flex items-center">
        <Icon name="Headphones" size={20} className="mr-2 text-primary" />
        Need Additional Help?
      </h3>
      <p className="text-sm text-text-secondary mb-4">
        If you're still having trouble with email verification, our support team is here to help.
      </p>
      <div className="space-y-3">
        {supportOptions?.map((option) => (
          <div key={option?.id} className="flex items-center justify-between p-3 border border-border rounded-md hover:bg-muted transition-smooth">
            <div className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                <Icon name={option?.icon} size={20} className="text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-text-primary">
                  {option?.title}
                </h4>
                <p className="text-xs text-text-secondary">
                  {option?.description}
                </p>
                <p className="text-xs text-text-secondary font-medium">
                  {option?.contact}
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleContactSupport(option)}
            >
              {option?.action}
            </Button>
          </div>
        ))}
      </div>
      <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
        <div className="flex items-start space-x-2">
          <Icon name="Info" size={16} className="text-primary mt-0.5" />
          <div>
            <p className="text-xs text-text-primary font-medium">
              Quick Tip
            </p>
            <p className="text-xs text-text-secondary">
              Include your registered email address when contacting support for faster assistance.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSupport;