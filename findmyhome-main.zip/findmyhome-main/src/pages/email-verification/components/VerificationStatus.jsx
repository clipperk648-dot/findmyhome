import React from 'react';
import Icon from '../../../components/AppIcon';

const VerificationStatus = ({ status, email }) => {
  const getStatusConfig = () => {
    switch (status) {
      case 'sent':
        return {
          icon: 'Mail',
          iconColor: 'text-primary',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200',
          title: 'Verification Email Sent',
          message: `We've sent a verification link to ${email}. Please check your inbox and click the link to activate your account.`
        };
      case 'verified':
        return {
          icon: 'CheckCircle',
          iconColor: 'text-success',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-200',
          title: 'Email Verified Successfully',
          message: 'Your email has been verified! You can now access all features of FindMyHome.'
        };
      case 'expired':
        return {
          icon: 'AlertCircle',
          iconColor: 'text-warning',
          bgColor: 'bg-yellow-50',
          borderColor: 'border-yellow-200',
          title: 'Verification Link Expired',
          message: 'The verification link has expired. Please request a new verification email to continue.'
        };
      case 'error':
        return {
          icon: 'XCircle',
          iconColor: 'text-error',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200',
          title: 'Verification Failed',
          message: 'There was an issue verifying your email. Please try again or contact support if the problem persists.'
        };
      default:
        return {
          icon: 'Mail',
          iconColor: 'text-primary',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200',
          title: 'Email Verification Required',
          message: 'Please verify your email address to complete your account setup.'
        };
    }
  };

  const config = getStatusConfig();

  return (
    <div className={`p-6 rounded-lg border-2 ${config?.bgColor} ${config?.borderColor} text-center`}>
      <div className="flex justify-center mb-4">
        <div className={`p-3 rounded-full bg-white shadow-soft`}>
          <Icon name={config?.icon} size={32} className={config?.iconColor} />
        </div>
      </div>
      <h2 className="text-xl font-semibold text-text-primary mb-2">
        {config?.title}
      </h2>
      <p className="text-text-secondary leading-relaxed">
        {config?.message}
      </p>
    </div>
  );
};

export default VerificationStatus;