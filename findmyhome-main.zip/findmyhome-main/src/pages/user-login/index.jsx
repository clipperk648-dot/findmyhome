import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import SocialLogin from './components/SocialLogin';
import SecurityFeatures from './components/SecurityFeatures';
import Icon from '../../components/AppIcon';

const UserLogin = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (isAuthenticated === 'true') {
      navigate('/user-dashboard');
    }

    // Auto-fill email if remember me was checked
    const rememberMe = localStorage.getItem('rememberMe');
    const savedEmail = localStorage.getItem('userEmail');
    if (rememberMe === 'true' && savedEmail) {
      // This would be handled by the LoginForm component
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-100 relative overflow-hidden">
      {/* Clear Background Image without blur effects */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-60"
        style={{
          backgroundImage: `url('/assets/images/IMG-20250907-WA0032-1757267654547.jpg')`
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-sky-100/30 to-blue-200/20" />
      
      {/* Content wrapper without backdrop blur */}
      <div className="relative z-10">
        {/* Header - removed backdrop blur */}
        <header className="bg-white/95 border-b border-sky-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center space-x-2">
                <div className="flex items-center justify-center w-8 h-8 bg-sky-500 rounded-lg shadow-sm">
                  <Icon name="Home" size={20} color="white" />
                </div>
                <span className="text-xl font-semibold text-sky-900">FindMyHome</span>
              </div>
              
              <nav className="hidden md:flex items-center space-x-6">
                <a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">
                  About
                </a>
                <a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">
                  Properties
                </a>
                <a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">
                  Contact
                </a>
              </nav>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left Side - Welcome Content */}
              <div className="hidden lg:block">
                <div className="max-w-lg">
                  <h1 className="text-4xl font-bold text-sky-900 mb-6">
                    Find Your Perfect Home
                  </h1>
                  
                  <p className="text-lg text-sky-700 mb-8">
                    Access thousands of verified property listings, save your favorites, and get personalized recommendations based on your preferences.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                        <Icon name="Search" size={16} color="rgb(16 185 129)" />
                      </div>
                      <span className="text-sky-800">Advanced property search filters</span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                        <Icon name="Heart" size={16} color="rgb(16 185 129)" />
                      </div>
                      <span className="text-sky-800">Save and organize favorite properties</span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                        <Icon name="Bell" size={16} color="rgb(16 185 129)" />
                      </div>
                      <span className="text-sky-800">Get alerts for new matching properties</span>
                    </div>
                  </div>

                  {/* Removed backdrop blur from info card */}
                  <div className="mt-8 p-4 bg-white/90 rounded-lg border border-sky-200 shadow-sm">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="Users" size={16} color="rgb(14 116 144)" />
                      <span className="text-sm font-medium text-sky-900">Trusted Platform</span>
                    </div>
                    <p className="text-sm text-sky-700">
                      Join over 50,000 users who have found their dream homes through our platform
                    </p>
                  </div>
                </div>
              </div>

              {/* Right Side - Login Form - removed backdrop blur */}
              <div className="w-full">
                <div className="bg-white/95 rounded-2xl shadow-lg border border-sky-200 p-1">
                  <LoginForm />
                  <SocialLogin />
                  <SecurityFeatures />
                </div>
              </div>
            </div>
          </div>
        </main>

        {/* Footer - removed backdrop blur */}
        <footer className="bg-white/95 border-t border-sky-200 mt-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="col-span-1 md:col-span-2">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="flex items-center justify-center w-8 h-8 bg-sky-500 rounded-lg shadow-sm">
                    <Icon name="Home" size={20} color="white" />
                  </div>
                  <span className="text-xl font-semibold text-sky-900">FindMyHome</span>
                </div>
                <p className="text-sky-700 mb-4">
                  Your trusted partner in finding the perfect home. We connect buyers and renters with their ideal properties.
                </p>
                <div className="flex space-x-4">
                  <a href="#" className="text-sky-600 hover:text-sky-800 transition-smooth">
                    <Icon name="Facebook" size={20} />
                  </a>
                  <a href="#" className="text-sky-600 hover:text-sky-800 transition-smooth">
                    <Icon name="Twitter" size={20} />
                  </a>
                  <a href="#" className="text-sky-600 hover:text-sky-800 transition-smooth">
                    <Icon name="Instagram" size={20} />
                  </a>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-sky-900 mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">About Us</a></li>
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Properties</a></li>
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Agents</a></li>
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Contact</a></li>
                </ul>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-sky-900 mb-4">Support</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Help Center</a></li>
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Privacy Policy</a></li>
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Terms of Service</a></li>
                  <li><a href="#" className="text-sky-700 hover:text-sky-900 transition-smooth">Cookie Policy</a></li>
                </ul>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-sky-200">
              <div className="flex flex-col md:flex-row justify-between items-center">
                <p className="text-sky-600 text-sm">
                  © {new Date()?.getFullYear()} FindMyHome. All rights reserved.
                </p>
                <div className="flex items-center space-x-4 mt-4 md:mt-0">
                  <div className="flex items-center space-x-2">
                    <Icon name="Shield" size={16} color="rgb(16 185 129)" />
                    <span className="text-xs text-sky-600">SSL Secured</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Lock" size={16} color="rgb(16 185 129)" />
                    <span className="text-xs text-sky-600">Privacy Protected</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default UserLogin;