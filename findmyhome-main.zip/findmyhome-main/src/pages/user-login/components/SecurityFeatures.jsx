import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityFeatures = () => {
  const securityFeatures = [
    {
      icon: 'Shield',
      title: 'SSL Encrypted',
      description: 'Your data is protected with 256-bit SSL encryption'
    },
    {
      icon: 'Lock',
      title: 'Secure Login',
      description: 'Advanced security measures protect your account'
    },
    {
      icon: 'Eye',
      title: 'Privacy First',
      description: 'We never share your personal information'
    }
  ];

  return (
    <div className="w-full max-w-md mx-auto mt-8">
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="text-center mb-4">
          <h3 className="text-sm font-medium text-text-primary mb-1">Your Security Matters</h3>
          <p className="text-xs text-text-secondary">FindMyHome uses industry-standard security</p>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {securityFeatures?.map((feature, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-success/10 rounded-full flex items-center justify-center">
                  <Icon name={feature?.icon} size={14} color="var(--color-success)" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-text-primary">{feature?.title}</p>
                <p className="text-xs text-text-secondary">{feature?.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-border">
          <div className="flex items-center justify-center space-x-2">
            <Icon name="CheckCircle" size={14} color="var(--color-success)" />
            <span className="text-xs text-text-secondary">Trusted by 50,000+ users</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityFeatures;