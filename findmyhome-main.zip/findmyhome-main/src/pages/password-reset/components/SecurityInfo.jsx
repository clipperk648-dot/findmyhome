import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityInfo = () => {
  const securityFeatures = [
    {
      icon: 'Lock',
      title: 'Secure Reset Process',
      description: 'All password reset requests are encrypted and time-limited for your protection.'
    },
    {
      icon: 'Clock',
      title: '15-Minute Expiry',
      description: 'Reset links automatically expire after 15 minutes to prevent unauthorized access.'
    },
    {
      icon: 'Shield',
      title: 'Account Protection',
      description: 'Your existing password remains active until you successfully create a new one.'
    },
    {
      icon: 'Mail',
      title: 'Email Verification',
      description: 'Reset instructions are only sent to verified email addresses on file.'
    }
  ];

  return (
    <div className="w-full max-w-2xl mx-auto mt-8">
      <div className="text-center mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-2">Your Security Matters</h2>
        <p className="text-text-secondary">
          Learn how we protect your account during the password reset process
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {securityFeatures?.map((feature, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-4 shadow-soft">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={feature?.icon} size={20} color="var(--color-primary)" />
              </div>
              <div>
                <h3 className="font-medium text-text-primary mb-1">{feature?.title}</h3>
                <p className="text-sm text-text-secondary">{feature?.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-6 bg-accent/10 border border-accent/20 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-accent mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-1">Need Help?</h4>
            <p className="text-sm text-text-secondary">
              If you don't receive the reset email within 10 minutes, check your spam folder or contact our support team for assistance.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityInfo;