import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import ResetForm from './components/ResetForm';
import SecurityInfo from './components/SecurityInfo';

const PasswordReset = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/user-login" className="flex items-center space-x-2 transition-smooth hover:opacity-80">
              <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
                <Icon name="Home" size={20} color="white" />
              </div>
              <span className="text-xl font-semibold text-text-primary">FindMyHome</span>
            </Link>
            
            <nav className="hidden sm:flex items-center space-x-4">
              <Link to="/user-login" className="text-sm text-text-secondary hover:text-text-primary transition-smooth">
                Login
              </Link>
              <Link to="/user-registration" className="text-sm text-text-secondary hover:text-text-primary transition-smooth">
                Sign Up
              </Link>
            </nav>
          </div>
        </div>
      </header>
      {/* Main Content */}
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
          {/* Breadcrumb */}
          <nav className="flex items-center space-x-2 text-sm text-text-secondary mb-8">
            <Link to="/user-login" className="hover:text-text-primary transition-smooth">
              Login
            </Link>
            <Icon name="ChevronRight" size={16} />
            <span className="text-text-primary">Password Reset</span>
          </nav>

          {/* Reset Form Section */}
          <div className="flex flex-col lg:flex-row lg:space-x-12 items-start">
            <div className="w-full lg:w-1/2">
              <ResetForm />
            </div>

            {/* Side Information */}
            <div className="w-full lg:w-1/2 mt-8 lg:mt-0">
              <div className="bg-card rounded-lg border border-border p-6 shadow-soft">
                <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center">
                  <Icon name="HelpCircle" size={20} className="mr-2" />
                  Frequently Asked Questions
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-text-primary mb-1">How long does it take to receive the reset email?</h4>
                    <p className="text-sm text-text-secondary">
                      Reset emails are typically delivered within 2-5 minutes. If you don't see it, check your spam folder.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-text-primary mb-1">What if I don't have access to my email?</h4>
                    <p className="text-sm text-text-secondary">
                      Contact our support team with your account details, and we'll help you regain access to your account.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-text-primary mb-1">Can I use the reset link multiple times?</h4>
                    <p className="text-sm text-text-secondary">
                      No, each reset link can only be used once and expires after 15 minutes for security reasons.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-text-primary mb-1">Is my account secure during this process?</h4>
                    <p className="text-sm text-text-secondary">
                      Yes, your current password remains active until you successfully create a new one.
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-border">
                  <div className="flex items-center space-x-2 text-sm text-text-secondary">
                    <Icon name="Phone" size={16} />
                    <span>Need help? Call us at (555) 123-4567</span>
                  </div>
                </div>
              </div>

              {/* Alternative Options */}
              <div className="mt-6 bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium text-text-primary mb-3">Other Options</h4>
                <div className="space-y-2">
                  <Link 
                    to="/user-registration" 
                    className="flex items-center space-x-2 text-sm text-text-secondary hover:text-text-primary transition-smooth"
                  >
                    <Icon name="UserPlus" size={16} />
                    <span>Create a new account</span>
                  </Link>
                  <Link 
                    to="/user-login" 
                    className="flex items-center space-x-2 text-sm text-text-secondary hover:text-text-primary transition-smooth"
                  >
                    <Icon name="ArrowLeft" size={16} />
                    <span>Back to login</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Security Information */}
          <SecurityInfo />
        </div>
      </main>
      {/* Footer */}
      <footer className="border-t border-border bg-surface mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
                  <Icon name="Home" size={20} color="white" />
                </div>
                <span className="text-xl font-semibold text-text-primary">FindMyHome</span>
              </div>
              <p className="text-sm text-text-secondary mb-4">
                Your trusted partner in finding the perfect home. Secure, reliable, and always here to help.
              </p>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-sm text-text-secondary">
                  <Icon name="Shield" size={16} />
                  <span>SSL Secured</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-text-secondary">
                  <Icon name="Lock" size={16} />
                  <span>Privacy Protected</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-text-primary mb-3">Support</h4>
              <div className="space-y-2">
                <Link to="/help" className="block text-sm text-text-secondary hover:text-text-primary transition-smooth">
                  Help Center
                </Link>
                <Link to="/contact" className="block text-sm text-text-secondary hover:text-text-primary transition-smooth">
                  Contact Us
                </Link>
                <a href="tel:5551234567" className="block text-sm text-text-secondary hover:text-text-primary transition-smooth">
                  (555) 123-4567
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-text-primary mb-3">Legal</h4>
              <div className="space-y-2">
                <Link to="/privacy" className="block text-sm text-text-secondary hover:text-text-primary transition-smooth">
                  Privacy Policy
                </Link>
                <Link to="/terms" className="block text-sm text-text-secondary hover:text-text-primary transition-smooth">
                  Terms of Service
                </Link>
                <Link to="/security" className="block text-sm text-text-secondary hover:text-text-primary transition-smooth">
                  Security
                </Link>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-border">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <p className="text-sm text-text-secondary">
                © {new Date()?.getFullYear()} FindMyHome. All rights reserved.
              </p>
              <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                <div className="flex items-center space-x-2 text-xs text-text-secondary">
                  <Icon name="Globe" size={14} />
                  <span>English (US)</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-text-secondary">
                  <Icon name="DollarSign" size={14} />
                  <span>USD</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PasswordReset;